package com.example.practicekotlin

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import kotlinx.android.synthetic.main.activity_ji_stagram_upload.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class JiStagramUploadActivity : AppCompatActivity() {


    lateinit var filePath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ji_stagram_upload)


        view_pictures.setOnClickListener {
            getPicture()
        }
        upload_post.setOnClickListener {
            uploadPost()
        }

        all_list.setOnClickListener {
            startActivity(Intent(this@JiStagramUploadActivity, JistagramPostListActivity::class.java))
        }
        my_list.setOnClickListener {
            startActivity(Intent(this@JiStagramUploadActivity, JiStagramMyPostListActivity::class.java))
        }
        user_info.setOnClickListener {
            startActivity(Intent(this@JiStagramUploadActivity, JiStagramUserInfo::class.java))
        }
    }

    fun getPicture() {

        val intent = Intent(Intent.ACTION_PICK)
        intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.setType("image/*")
        startActivityForResult(intent, 1000)
    }

    // 절대 경로를 얻기 위한 과정
    fun getImageFilePath(contentUri: Uri): String {
        // 인덱스
        var columIndex = 0
        // 걸러내기 위한 변수
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        // index에서 가리키기 위한 변수
        val cursor = contentResolver.query(contentUri, projection, null, null, null)

        if (cursor!!.moveToFirst()) {
            columIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        }

        return cursor.getString(columIndex)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 1000) {
            val uri : Uri = data!!.data!!  // 실제 파일이 위치한 주소와 다름
            filePath = getImageFilePath(uri)
        }
    }

    fun uploadPost() {
        val file = File(filePath)
        val fileRequestBody = RequestBody.create(MediaType.parse("image/*"), file)
        val part = MultipartBody.Part.createFormData("image", file.name, fileRequestBody)
        val content = RequestBody.create(MediaType.parse("text/plain"), getContent())

        (application as MasterApplication).service.uploadPost(
            part, content
        ).enqueue(object: Callback<Post> {
            override fun onFailure(call: Call<Post>, t: Throwable) {

            }

            override fun onResponse(call: Call<Post>, response: Response<Post>) {
                if (response.isSuccessful) {
                    finish()
                    startActivity(Intent(this@JiStagramUploadActivity, JiStagramMyPostListActivity::class.java))
                }
            }
        })
    }

    fun getContent(): String{
        return content_input.text.toString()
    }

}
