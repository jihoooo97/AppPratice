package com.example.practicekotlin

import java.io.Serializable

class User(
    var username: String? = null,
    var token: String? = null
): Serializable